<div class="lcPageContentPay lcPageContentPay-active">
    <div class="lcPageContentPayMiddle">
        <div class="lcPageContentPayMiddle__item">
            <div class="lcPageContentPayMiddle__check "><span></span>
                <input name="choose" type="radio">
            </div>
            <div class="lcPageContentPayMiddle__inf" data-modal="#modal3">
                Банковские карты<span>Комиссия 20%</span>
            </div>
            <div class="lcPageContentPayMiddle__img">
                <img src="http://laramarket/img/pay/mastercard1.png" alt="">
            </div>
            <input type="hidden" name="payment_method" value="visa">
        </div>
    </div>
</div>