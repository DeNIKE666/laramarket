<div class="catalogTop__sort">
                        <span>
                            Сортировать по:
                        </span>
    <div class="catalogSort">
        <span>По популярности</span>
        <svg
                xmlns="http://www.w3.org/2000/svg"
                xmlns:xlink="http://www.w3.org/1999/xlink"
                width="12px" height="6px">
            <path fill-rule="evenodd"  fill="rgb(153, 153, 153)"
                  d="M-0.000,-0.000 L12.000,-0.000 L6.000,6.000 L-0.000,-0.000 Z"/>
        </svg>
        <div class="catalogSort__drop">
                                <span>
                                    По цене
                                </span>
            <span>
                                    По качеству
                                </span>
            <span>
                                    По размеру
                                </span>
        </div>
    </div>
</div>