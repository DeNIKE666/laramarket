
<script src="{{ asset('vendors/js/vendor.bundle.base.js') }}"></script>
<!--
<script src="{{ asset('vendors/chart.js/Chart.min.js') }}"></script>
<script src="{{ asset('vendors/moment/moment.min.js') }}"></script>
<script src="{{ asset('vendors/daterangepicker/daterangepicker.js') }}"></script>
<script src="{{ asset('/vendors/chartist/chartist.min.js') }}"></script>

<script src="{{ asset('js/off-canvas.js') }}"></script>
<script src="{{ asset('js/misc.js') }}"></script>

<script src="{{ asset('/js/dashboard.js') }}"></script>
 -->
