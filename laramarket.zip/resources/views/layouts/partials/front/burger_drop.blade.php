
<div class="burgerDropWrap">
    <div class="burgerDrop">
        <div class="burgerDrop__close">
            <svg
                    xmlns="http://www.w3.org/2000/svg"
                    xmlns:xlink="http://www.w3.org/1999/xlink"
                    width="26px" height="9px">
                <path fill-rule="evenodd"  fill="rgb(51, 51, 51)"
                      d="M4.129,3.499 L26.000,3.499 L26.000,5.499 L4.129,5.499 L6.258,7.500 L4.710,9.000 L0.000,4.499 L4.710,-0.001 L6.258,1.500 L4.129,3.499 Z"/>
            </svg>
        </div>
        <div class="burgerDrop__title">
            Категории товаров
        </div>
        <div class="burgerDropNav">
            <div class="burgerDropNav__item">
                <div class="radio">
                        <span>

                        </span>
                </div>
                <span>
                        Одежда, обувь и аксессуары
                    </span>
                <div class="burgerDropNav">
                    <div class="burgerDropNav__item">
                        <div class="radio">
                                <span>

                                </span>
                        </div>
                        <span>
                                Одежда, обувь и аксессуары
                            </span>
                        <div class="burgerDropNav">
                            <div class="burgerDropNav__item">
                                <div class="radio">
                                        <span>

                                        </span>
                                </div>
                                <span>
                                        Одежда, обувь и аксессуары
                                    </span>
                                <div class="burgerDropNav">
                                    <div class="burgerDropNav__item">
                                        <div class="radio">
                                                <span>

                                                </span>
                                        </div>
                                        <span>
                                                Одежда, обувь и аксессуары
                                            </span>
                                    </div>
                                    <div class="burgerDropNav__item">
                                        <div class="radio">
                                                <span>

                                                </span>
                                        </div>
                                        <span>
                                                Аптека
                                            </span>
                                    </div>
                                </div>
                            </div>
                            <div class="burgerDropNav__item">
                                <div class="radio">
                                        <span>

                                        </span>
                                </div>
                                <span>
                                        Аптека
                                    </span>
                            </div>
                            <div class="burgerDropNav__item">
                                <div class="radio">
                                        <span>

                                        </span>
                                </div>
                                <span>
                                        Бытовая техника
                                    </span>
                            </div>
                            <div class="burgerDropNav__item">
                                <div class="radio">
                                        <span>

                                        </span>
                                </div>
                                <span>
                                        Продукты питания
                                    </span>
                            </div>
                        </div>
                    </div>
                    <div class="burgerDropNav__item">
                        <div class="radio">
                                <span>

                                </span>
                        </div>
                        <span>
                                Аптека
                            </span>
                    </div>
                    <div class="burgerDropNav__item">
                        <div class="radio">
                                <span>

                                </span>
                        </div>
                        <span>
                                Бытовая техника
                            </span>
                    </div>
                    <div class="burgerDropNav__item">
                        <div class="radio">
                                <span>

                                </span>
                        </div>
                        <span>
                                Продукты питания
                            </span>
                    </div>
                    <div class="burgerDropNav__item">
                        <div class="radio">
                                <span>

                                </span>
                        </div>
                        <span>
                                Строительство и ремонт
                            </span>
                    </div>
                    <div class="burgerDropNav__item">
                        <div class="radio">
                                <span>

                                </span>
                        </div>
                        <span>
                                Красота и здоровье
                            </span>
                    </div>
                    <div class="burgerDropNav__item">
                        <div class="radio">
                                <span>

                                </span>
                        </div>
                        <span>
                                Спортивные товары
                            </span>
                    </div>
                </div>
            </div>
            <div class="burgerDropNav__item">
                <div class="radio">
                        <span>

                        </span>
                </div>
                <span>
                        Аптека
                    </span>
            </div>
            <div class="burgerDropNav__item">
                <div class="radio">
                        <span>

                        </span>
                </div>
                <span>
                        Бытовая техника
                    </span>
            </div>
            <div class="burgerDropNav__item">
                <div class="radio">
                        <span>

                        </span>
                </div>
                <span>
                        Продукты питания
                    </span>
            </div>
            <div class="burgerDropNav__item">
                <div class="radio">
                        <span>

                        </span>
                </div>
                <span>
                        Строительство и ремонт
                    </span>
            </div>
            <div class="burgerDropNav__item">
                <div class="radio">
                        <span>

                        </span>
                </div>
                <span>
                        Красота и здоровье
                    </span>
            </div>
            <div class="burgerDropNav__item">
                <div class="radio">
                        <span>

                        </span>
                </div>
                <span>
                        Спортивные товары
                    </span>
            </div>
            <div class="burgerDropNav__item">
                <div class="radio">
                        <span>

                        </span>
                </div>
                <span>
                        Товары для животных
                    </span>
            </div>
            <div class="burgerDropNav__item">
                <div class="radio">
                        <span>

                        </span>
                </div>
                <span>
                        Книги
                    </span>
            </div>
            <div class="burgerDropNav__item">
                <div class="radio">
                        <span>

                        </span>
                </div>
                <span>
                        Хобби и творчество
                    </span>
            </div>
        </div>
        <button class="burgerDrop__btn btn">
            Посмотреть
        </button>
    </div>
</div>
