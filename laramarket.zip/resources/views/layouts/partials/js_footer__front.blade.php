<script src="{{ asset('js/axios.min.js') }}"></script>
<script src="{{ asset('js/all.js') }}"></script>
<script src="{{ asset('js/main.js') }}"></script>

@stack('scripts')