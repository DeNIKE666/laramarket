<script src="{{ asset('js/axios.min.js') }}"></script>
<script src="{{ asset('js/all.js') }}"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/2.1.0/js/toastr.js"></script>
<link rel="stylesheet" type="text/css" href="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">

<script src="{{ asset('js/main.js') }}"></script>


@stack('scripts')