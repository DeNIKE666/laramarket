<div class="lcPageContentRow">
    <div class="lcPageContentCol">{{ $order->id }}</div>
    <div class="lcPageContentCol">{{ $order->cost }}</div>
    <div class="lcPageContentCol">{{ $order->status }}</div>
    <div class="lcPageContentCol">{{ $order->created_at }}</div>
    <div class="lcPageContentCol">
        <a href="">
            Подробнее
        </a>
    </div>
</div>

