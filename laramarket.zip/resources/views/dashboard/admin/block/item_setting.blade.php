<tr>
    <td>{{ $setting->id }}</td>
    <td>{{ $setting->slug }}</td>
    <td>{{ $setting->name }}</td>
    <td>{{ $setting->value }}</td>
</tr>
