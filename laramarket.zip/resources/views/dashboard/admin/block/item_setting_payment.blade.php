<tr>
    <td>{{ $setting->min_percent }}</td>
    <td>{{ $setting->max_percent }}</td>
    <td>{{ $setting->quantity_pay_every_month }}</td>
    <td>{{ $setting->quantity_pay_each_quarter }}</td>
    <td>{{ $setting->quantity_pay_every_six_months }}</td>
    <td>{{ $setting->quantity_pay_single }}</td>
</tr>
