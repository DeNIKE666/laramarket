<div class="lcPageContentProductsSort lcPageContentSort">
    <div class="lcPageContentSort__item">
                                <span>
                                    По цене (руб).
                                </span>
        <input type="text" placeholder="от 100">
        <input type="text" placeholder="от 1 000 000">
    </div>
    <div class="lcPageContentSort__item">
                                <span>
                                    По дате:
                                </span>
        <input type="text" placeholder="с 18.07.2020">
        <input type="text" placeholder="по 18.07.2020">
    </div>
    <div class="lcPageContentSort__item">
                                <span>
                                    По статусу:
                                </span>
        <div class="catalogTop__sort">
            <div class="catalogSort">
                <span>Принят в обработку</span>
                <svg
                        xmlns="http://www.w3.org/2000/svg"
                        xmlns:xlink="http://www.w3.org/1999/xlink"
                        width="12px" height="6px">
                    <path fill-rule="evenodd" fill="rgb(153, 153, 153)"
                          d="M-0.000,-0.000 L12.000,-0.000 L6.000,6.000 L-0.000,-0.000 Z"/>
                </svg>
                <div class="catalogSort__drop">
                                            <span>
                                                Принят в обработку
                                            </span>
                    <span>
                                                Принят в обработку
                                            </span>
                    <span>
                                                Принят в обработку
                                            </span>
                </div>
            </div>
        </div>
    </div>
    <div class="lcPageContentSort__item">
                                <span>
                                    Комиссия:
                                </span>
        <div class="catalogTop__sort catalogTop__sort-min">
            <div class="catalogSort">
                <span>50%</span>
                <svg
                        xmlns="http://www.w3.org/2000/svg"
                        xmlns:xlink="http://www.w3.org/1999/xlink"
                        width="12px" height="6px">
                    <path fill-rule="evenodd" fill="rgb(153, 153, 153)"
                          d="M-0.000,-0.000 L12.000,-0.000 L6.000,6.000 L-0.000,-0.000 Z"/>
                </svg>
                <div class="catalogSort__drop">
                                            <span>
                                                50%
                                            </span>
                    <span>
                                                50%
                                            </span>
                    <span>
                                                50%
                                            </span>
                </div>
            </div>
        </div>
    </div>
    <button class="lcPageContentSort__btn btn">
        Применить
    </button>
</div>
