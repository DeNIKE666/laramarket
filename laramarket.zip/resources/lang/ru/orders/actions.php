<?php
return [
    'cancel'   => 'Отменить',
    'received' => 'Товар получен',
    'waiting'  => 'Ожидание',
    'confirm'  => 'Подтвердить',
];
