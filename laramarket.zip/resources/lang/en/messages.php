<?php

return [
    "Remember" => "Remember Me",
    "Forgot_Password?" => "Forgot Your Password?",
    "not_account?" => "Don't have an account?",
    "create" => "Create",
    "hello_login" => "Привет! давайте начнем",
    "desc_login" => "Войдите в систему, чтобы продолжить работу."
];
