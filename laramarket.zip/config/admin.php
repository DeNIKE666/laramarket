<?php
return [
    'extensions' => [

        'summernote' => [

            //Set to false if you want to disable this extension
            'enable' => true,

            // Editor configuration
            'config' => [
                'lang'   => 'ru-RU',
                'height' => 500,
            ]
        ]
    ]
];
