$(document).ready(function() {
    $('.textarea').ckeditor();
    $('.select').select2();
});