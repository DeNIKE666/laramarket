<?php
namespace App\Contracts;


interface OrderContract
{
    public function storeOrderDetails($params);
}
