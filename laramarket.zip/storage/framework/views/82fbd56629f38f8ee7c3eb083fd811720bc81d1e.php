

<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('front.partials.breadcrumbs', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="block-cart">
        <div class="wrapper">
            <h1 class="title">Заказ #<?php echo e($order->id); ?></h1>

            <?php echo $__env->make('__shared.pay-method.' . $payment, [
               'order' => $order
            ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        </div>
    </div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\OSPanel\domains\laramarket\resources\views/front/page/checkout_info.blade.php ENDPATH**/ ?>