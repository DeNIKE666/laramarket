<div class="lcPageContentTop">

    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->denies('role-admin')): ?>
    <a href="<?php echo e(route('adminIndex')); ?>"
       class="lcPageContentTop__btn <?php echo e(request()->is('dashboard/buyer/*') ? 'lcPageContentTop__btn-active btn-blue' : null); ?> ">
        Кабинет покупателя
    </a>
    <?php endif; ?>

    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role-shop')): ?>
    <a href="<?php echo e(route('seller_status')); ?>"
       class="lcPageContentTop__btn <?php echo e(request()->is('dashboard/shop/*') ? 'lcPageContentTop__btn-active btn-blue' : null); ?> ">
        Кабинет продавца
    </a>
    <?php endif; ?>

    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('is-partner')): ?>
    <a class="lcPageContentTop__btn">
        Кабинет партнёра
    </a>
    <?php endif; ?>

    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role-admin')): ?>
        <a class="lcPageContentTop__btn <?php echo e(request()->is('dashboard/admin/*') ? 'lcPageContentTop__btn-active btn-blue' : null); ?>">
            Кабинет администратора
        </a>
    <?php endif; ?>
</div><?php /**PATH E:\OSPanel\domains\laramarket\resources\views/dashboard/partials/cabinet_top_nav.blade.php ENDPATH**/ ?>