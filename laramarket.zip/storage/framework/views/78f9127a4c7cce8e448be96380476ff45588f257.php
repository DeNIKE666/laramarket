

<?php $__env->startSection('content'); ?>

    <div class="lcPageContentTable">
        <div class="lcPageContentRow">
            <div class="lcPageContentCol">
                № Заказа
            </div>
            <div class="lcPageContentCol">
                Дата заказа
            </div>
            <div class="lcPageContentCol">
                Сумма заказа
            </div>
            <div class="lcPageContentCol">
                Статус заказа
            </div>
        </div>

        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="lcPageContentRow">
                <div class="lcPageContentCol">
                    <?php echo e($order->id); ?>

                </div>

                <div class="lcPageContentCol">
                    <?php echo e($order->created_at); ?>

                </div>

                <div class="lcPageContentCol">
                    <?php echo e($order->cost); ?> руб.
                </div>

                <div class="lcPageContentCol">
                    <?php if($order->status == 'pending'): ?>
                        Не оплачен
                    <?php elseif($order->status == 'PAID'): ?>
                        Принят в обработку
                    <?php endif; ?>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\OSPanel\domains\laramarket\resources\views/dashboard/user/my_order.blade.php ENDPATH**/ ?>