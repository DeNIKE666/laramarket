<?php if(count($tasks)): ?>
        <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="lcPageHelpArchLeft__item">
                <a href="<?php echo e(route('tasks.show', $task->id)); ?>#chat">
                    <span>
                        # <?php echo e($task->id); ?>

                    </span>
                    <p>
                        <?php echo e($task->title); ?>

                    </p>
                </a>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php else: ?>
    <div class="lcPageHelpArchLeft__item">
        <p>Нет обращений</p>
    </div>
<?php endif; ?>

<?php /**PATH E:\OSPanel\domains\laramarket\resources\views/dashboard/task/block/list_message.blade.php ENDPATH**/ ?>