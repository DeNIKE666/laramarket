<div class="catalogDropWrap">
    <div class="catalogDrop">
        <?php if(count($navbarCategories)): ?>

            <div class="catalogDrop__left">
            <?php $__currentLoopData = $navbarCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($category->isActive() && $category->depth == 0): ?>

                <a data-nav="<?php echo e($category->id); ?>" href="<?php echo e($category->getPath()); ?>" class="catalogDrop__item <?php if($loop->first): ?> catalogDrop__item-active <?php endif; ?>">
                    <?php echo e($category->title); ?>

                </a>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <?php $__currentLoopData = $navbarCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($category->isActive()): ?>
                    <?php if($category->depth == 0): ?>
                        <?php if($k == 0): ?>
                            <div data-parent="<?php echo e($category->id); ?>" class="catalogDrop__right catalogDrop__right-show">
                        <?php else: ?>
                            <?php if($navbarCategories[$k-1]->depth - $category->depth > 0): ?>
                                </div>
                            <?php endif; ?>
                            </div>
                            <div data-parent="<?php echo e($category->id); ?>" class="catalogDrop__right">
                        <?php endif; ?>
                    <?php else: ?>
                        <?php if($category->depth == 1): ?>
                            <?php if($navbarCategories[$k-1]->depth - $category->depth > 0): ?>
                                </div>
                            <?php endif; ?>
                            <div class="catalogDrop__menu">
                                <a href="<?php echo e($category->getPath()); ?>">
                                    <?php echo e($category->title); ?>

                                </a>
                        <?php else: ?>
                            <a href="<?php echo e($category->getPath()); ?>">
                                <?php echo e($category->title); ?>

                            </a>
                        <?php endif; ?>
                    <?php endif; ?>

                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
        <?php endif; ?>
    </div>
</div>


<div class="burgerDropWrap">
    <div class="burgerDrop">
        <div class="burgerDrop__close">
            <svg
                    xmlns="http://www.w3.org/2000/svg"
                    xmlns:xlink="http://www.w3.org/1999/xlink"
                    width="26px" height="9px">
                <path fill-rule="evenodd"  fill="rgb(51, 51, 51)"
                      d="M4.129,3.499 L26.000,3.499 L26.000,5.499 L4.129,5.499 L6.258,7.500 L4.710,9.000 L0.000,4.499 L4.710,-0.001 L6.258,1.500 L4.129,3.499 Z"/>
            </svg>
        </div>
        <div class="burgerDrop__title">
            Категории товаров
        </div>
        <form>
        <div class="burgerDropNav">
            <?php if(count($navbarCategories)): ?>
                <?php $__currentLoopData = $navbarCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($category->isActive()): ?>
                        <?php if($category->depth == 0): ?>
                            <label class="burgerDropNav__item">
                                <input type="radio" name="cat" value="<?php echo e($category->id); ?>">
                                <div class="radio">
                                    <span></span>
                                </div>
                                <span><?php echo e($category->title); ?></span>
                                <?php if(isset($navbarCategories[$k+1])): ?>
                                    <?php if($navbarCategories[$k+1]->depth > 0): ?>
                                        <?php echo $__env->make('layouts.partials.front.item_mob_nav', ['navbarCategories' => $navbarCategories, 'current' => $k+1], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </label>
                        <?php endif; ?>

                    <?php endif; ?>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            <?php endif; ?>
        </div>
        <button class="burgerDrop__btn btn">
            Посмотреть
        </button>
        </form>
    </div>
</div>
<?php /**PATH E:\OSPanel\domains\laramarket\resources\views/front/partials/navbar_categories.blade.php ENDPATH**/ ?>