<script src="<?php echo e(asset('js/axios.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/all.js')); ?>"></script>
<script src="<?php echo e(asset('js/main.js')); ?>"></script>

<?php echo $__env->yieldPushContent('scripts'); ?><?php /**PATH E:\OSPanel\domains\laramarket\resources\views/layouts/partials/js_footer__front.blade.php ENDPATH**/ ?>