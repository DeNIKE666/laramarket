

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('front.partials.breadcrumbs', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="wrapper">
        <form method="POST" class="form-center" action="<?php echo e(route('login')); ?>">
            <?php echo csrf_field(); ?>
            <h1 class="form-center__title">Регистрация</h1>
            <div class="form-group">
                <input
                        id="email"
                        type="email"
                        class="popUp__inp <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        name="email"
                        value="<?php echo e(old('email')); ?>"
                        autocomplete="email"
                        autofocus
                        placeholder="Email"
                >

                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            </div>
            <div class="form-group">

                <input id="password"
                       type="password"
                       class="popUp__inp <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                       name="password"
                       autocomplete="current-password"
                       placeholder="Пароль"
                >

                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            </div>
            <div class="mt-3">
                <button class="popUp__btn btn btn-center" type="submit">ВОЙТИ</button>
            </div>
            <div class="form-center__footer">
                <div class="form-check">

                    <label class="form-check-label text-muted" for="remember">
                        <input class="form-check-input" type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>
                        <?php echo e(__('messages.Remember')); ?>

                    </label>

                </div>
                <?php if(Route::has('password.request')): ?>
                    <a class="auth-link text-black" href="<?php echo e(route('password.request')); ?>">
                        <?php echo e(__('messages.Forgot_Password?')); ?>

                    </a>
                <?php endif; ?>

            </div>

            <div class="text-center mt-4 font-weight-light"> <?php echo e(__('messages.not_account?')); ?> <a href="/register" class="text-primary"><?php echo e(__('messages.create')); ?></a>
            </div>
        </form>

    </div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\OSPanel\domains\laramarket\resources\views/auth/login.blade.php ENDPATH**/ ?>