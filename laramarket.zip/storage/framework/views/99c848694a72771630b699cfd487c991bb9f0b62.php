<a href="<?php echo e(route('adminIndex')); ?>"
   class="<?php echo e((request()->is('dashboard/buyer/index')) ? 'active' : ''); ?>">
    Личные данные
</a>
<a href="<?php echo e(route('user_orders_list')); ?>"
   class="<?php echo e((request()->is('dashboard/buyer/orders*')) ? 'active' : ''); ?>">
    Мои заказы
</a>
<a href="<?php echo e(route('user_history_order')); ?>"
   class="<?php echo e((request()->is('dashboard/buyer/history_orders*')) ? 'active' : ''); ?>">
    История заказов
</a>
<a href="<?php echo e(route('user_list_cashback')); ?>"
   class="<?php echo e((request()->is('dashboard/buyer/list_cashback*')) ? 'active' : ''); ?>">
    Кэшбэк
</a>
<a href="<?php echo e(route('user_pay')); ?>"
   class="<?php echo e((request()->is('dashboard/buyer/user_pay*')) ? 'active' : ''); ?>">
    Пополнение/снятие
</a>
<a href="<?php echo e(route('tasks.index')); ?>"
   class="<?php echo e((request()->is('dashboard/buyer/tasks*')) ? 'active' : ''); ?>">
    Помощь
</a><?php /**PATH E:\OSPanel\domains\laramarket\resources\views/dashboard/partials/nav_bayer.blade.php ENDPATH**/ ?>