<div class="lcPageMenu">
    <div class="lcPageMenuTop">
        <div class="lcPageMenuTop__img">
            <img src="<?php echo e(asset('img/photos/18.png')); ?>" alt="">
        </div>
        <div class="lcPageMenuTop__name">
            <?php echo e(auth()->user()->getName()); ?>

        </div>
    </div>

    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->denies('role-admin')): ?>

        <div class="lcPageMenuNav">
            <?php if(request()->is('dashboard/buyer/*')): ?>
                <?php echo $__env->make('dashboard.partials.nav_bayer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>
            <?php if(request()->is('dashboard/shop/*')): ?>
                <?php echo $__env->make('dashboard.partials.nav_seller', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>
        </div>
        <div class="lcPageMenuCash">
            Баланс:
            <span><?php echo e(auth()->user()->personal_account); ?> руб.</span>
        </div>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role-user')): ?>
            <?php if(auth()->user()->request_shop == 0): ?>
                <a href="<?php echo e(route('application_to_sellers')); ?>" class="btn lcPageMenu__btn">Стать продавцом</a>
            <?php else: ?>
                <p>Заявка на продовца отправлена скоро будет расмотренна</p>
            <?php endif; ?>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('is-partner')): ?>
            <p>Реферная ссылка для регисрации</p>
            <textarea style="height: 80px; line-height: 1.3; padding: 5px" class="form-control"
                      onfocus="this.select();"
                      readonly="readonly"><?php echo e(route('register_referral', auth()->user()->partner_token)); ?></textarea>
        <?php else: ?>
            <?php echo e(Form::open(['route' => [ 'active_partner'], 'method' => 'get'])); ?>

            <button type="submit" class="btn lcPageMenu__btn">Стать партнером</button>
            <?php echo e(Form::close()); ?>

        <?php endif; ?>

    <?php endif; ?>

    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role-admin')): ?>
        <?php echo $__env->make('dashboard.admin.block.nav_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>

</div>
<?php /**PATH E:\OSPanel\domains\laramarket\resources\views/dashboard/partials/cabinet_left_nav.blade.php ENDPATH**/ ?>