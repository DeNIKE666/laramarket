

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('front.partials.breadcrumbs', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="block-catalog">
        <div class="wrapper">
            <div class="catalogTop">
                <h1 class="catalogTop__title">
                    <?php echo e($category->title); ?>

                </h1>
                <?php echo $__env->make('front.partials.catalog_sort', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <div class="catalogTop__sum">
                    1946 товаров
                </div>
            </div>
            <div class="catalog">
                <?php echo $__env->make('front.partials.catalog_filter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="catalogContentWrap">
                    <div class="catalogContent">
                        <?php if(count($products)): ?>

                                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php echo $__env->make('front.partials.item_product', ['product' => $product], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\OSPanel\domains\laramarket\resources\views/front/page/catalog.blade.php ENDPATH**/ ?>