<a href="<?php echo e(route('seller_status')); ?>"
   class="<?php echo e((request()->is('dashboard/shop/index')) ? 'active' : ''); ?>">
    Панель состояния
</a>
<a href="<?php echo e(route('products.index')); ?>"
   class="<?php echo e((request()->is('dashboard/shop/products*')) ? 'active' : ''); ?>">
    Мои товары
</a>
<a href="">
    Мои продажи
</a>
<a href="">
    Данные продавца
</a>
<a href="<?php echo e(route('tasks.index')); ?>"
   class="<?php echo e((request()->is('dashboard/buyer/tasks*')) ? 'active' : ''); ?>">
    Помощь
</a><?php /**PATH E:\OSPanel\domains\laramarket\resources\views/dashboard/partials/nav_seller.blade.php ENDPATH**/ ?>