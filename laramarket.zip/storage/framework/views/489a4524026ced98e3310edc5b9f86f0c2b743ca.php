

<?php $__env->startSection('content'); ?>

    <div class="lcPageContentData">
        <div class="lcPageContentTitle">
            История заказов
        </div>
        <div class="lcPageContentData__title">
            Личные данные
        </div>
        <?php echo $__env->make('dashboard.user.profile', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\OSPanel\domains\laramarket\resources\views/dashboard/edit_profile.blade.php ENDPATH**/ ?>