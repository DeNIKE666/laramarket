

<?php $__env->startSection('content'); ?>

        <div class="row">
            <?php echo $__env->make('dashboard.user.profile', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role-user', $user)): ?>
            <?php echo $__env->make('dashboard.user.edit_form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>
        </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\OSPanel\domains\laramarket\resources\views/dashboard/index.blade.php ENDPATH**/ ?>