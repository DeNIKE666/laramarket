<div class="block-bc">
    <div class="wrapper">
        <div class="bc">
            <a href="">
                Главная
            </a>
            <span>></span>
            <a href="">
                Каталог
            </a>
            <span>></span>
            <a href="">
                Одежда
            </a>
        </div>
    </div>
</div><?php /**PATH E:\OSPanel\domains\laramarket\resources\views/front/partials/breadcrumbs.blade.php ENDPATH**/ ?>