<?php if($navbarCategories[$current-1]->depth < $navbarCategories[$current]->depth): ?>
<div class="burgerDropNav">
<?php endif; ?>
    <label class="burgerDropNav__item">
        <input type="radio" name="cat" value="<?php echo e($navbarCategories[$current]->id); ?>">
        <div class="radio">
            <span></span>
        </div>
        <span><?php echo e($navbarCategories[$current]->title); ?></span>
        <?php if(isset($navbarCategories[$current+1])): ?>
            <?php if($navbarCategories[$current+1]->depth > 0 && $navbarCategories[$current+1]->depth > $navbarCategories[$current]->depth): ?>
                <?php echo $__env->make('layouts.partials.front.item_mob_nav', ['navbarCategories' => $navbarCategories, 'current' => $current+1], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>
        <?php endif; ?>
    </label>
    <?php if(isset($navbarCategories[$current+1])): ?>
        <?php if($navbarCategories[$current+1]->depth > 0 && $navbarCategories[$current+1]->depth == $navbarCategories[$current]->depth): ?>
            <?php echo $__env->make('layouts.partials.front.item_mob_nav', ['navbarCategories' => $navbarCategories, 'current' => $current+1], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>
    <?php endif; ?>
<?php if($navbarCategories[$current-1]->depth < $navbarCategories[$current]->depth): ?>
</div>
<?php endif; ?><?php /**PATH E:\OSPanel\domains\laramarket\resources\views/layouts/partials/front/item_mob_nav.blade.php ENDPATH**/ ?>